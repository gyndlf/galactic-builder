# The definitions used for controlling the mysql database go here

import MySQLdb

if __name__ == '__main__':  # The file is run directly
    print('Error 321: Unknown values')
