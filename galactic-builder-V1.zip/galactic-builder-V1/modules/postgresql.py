# The definitions used for controlling the PostGreSQL database go here

if __name__ == '__main__':  # The file is run directly
    print('Error 321: Unknown values')
