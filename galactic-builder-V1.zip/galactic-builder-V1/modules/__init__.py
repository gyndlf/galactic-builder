# Initialise the other files if needed.
# Not sure if file is necessary

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

