**This is the galactic builder repo**

It is the source code for the website http://galactic-builder.xyz
Do not edit anything unless you have permisson and know what you are doing

Test github edit
