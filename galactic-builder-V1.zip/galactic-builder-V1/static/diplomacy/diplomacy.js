var data = [
{
name:"Joefish",
relations: ["", "green", "", "green", "green", "", "red"],
strength: 100,
},
{
name:"Slang",
relations: [ "green", "", "", "", "", "", ""],
strength: 100,
},
{
name:"Benions",
relations: [ "", "", "", "", "", "", ""],
strength: 100,
},
{
name:"Vexxors",
relations: [ "green", "", "", "", "", "", ""],
strength: 100,
},
{
name:"Vinitipu",
relations: [ "green", "", "", "", "", "", ""],
strength: 100,
},
{
name:"Humans",
relations: [ "", "", "", "", "", "", ""],
strength: 100,
},
{
name:"Gagners",
relations: [ "red", "", "", "", "", "",""],
strength: 100,
}
];
var factionNum = data.length;